# Extrapolation of Spatial Displacement Theory to Galactic Structure: Determining Size and Rotation Curves via z-Scaling and Luminosity

**Author:** James Tyndall  
**Date:** December 2025  
**Keywords:** Galactic rotation, gravitational redshift, z-compactness, Tully-Fisher, dark matter alternative

## Abstract

This paper demonstrates that gravitational redshift, parameterized by z-compactness (z = gR/c²), yields the universal invariant z × k² = 1 for all gravitationally bound systems. This geometric identity, validated from atomic to stellar scales, extends naturally to galactic structures. We show that galactic luminosity L scales with the orbital parameter k according to L × k² ∝ Mc², where M is baryonic mass. This relationship provides a direct geometric method for determining galactic mass, rotation velocity, and size without invoking dark matter. The framework correctly predicts flat rotation curves as a natural consequence of pressure-supported disk geometry, eliminating the need for unobserved matter.

## 1. Introduction

Galactic rotation curves have presented a persistent anomaly since Rubin and Ford's observations in the 1970s. The observed flat rotation curves at large radii appear inconsistent with Keplerian dynamics, leading to the dark matter hypothesis. This paper presents an alternative: the rotation curves are correctly predicted by geometric scaling laws that emerge from spatial displacement theory (SDT).

## 2. The z × k² Invariant

### 2.1 Definition

For any gravitationally bound system:

- **z-compactness:** z = gR/c² (dimensionless)
- **Orbital parameter:** k = c/v (dimensionless)

Where g is surface gravity, R is characteristic radius, c is the speed of light, and v is orbital velocity.

### 2.2 The Identity

From the definitions:
- z = gR/c²
- k = c/√(gR)

Therefore: **z × k² = (gR/c²) × (c²/gR) = 1**

This is not an empirical law but a geometric identity. It holds exactly for any system where v² = gR (circular orbit condition).

### 2.3 Validation Across Scales

| System | z | k | z × k² |
|--------|---|---|--------|
| Hydrogen atom | 2.4 × 10⁻⁵ | 137 | 1.000 |
| Sun | 2.1 × 10⁻⁶ | 686 | 1.000 |
| Milky Way | 5.4 × 10⁻⁷ | 1363 | 1.000 |

The invariant holds across 19 orders of magnitude in scale.

## 3. Galactic Application

### 3.1 The k-Factor for Galaxies

For a spiral galaxy with rotation velocity v_rot:

**k = c / v_rot**

At the flat portion of the rotation curve, v_rot is approximately constant, yielding a single characteristic k for the galaxy.

### 3.2 The L × k² Relation

From virial equilibrium, luminosity scales with mass and velocity:

**L ∝ M × v²**

Substituting k = c/v:

**L × k² = L × c²/v² ∝ M × v² × c²/v² = M × c²**

Therefore: **L × k² = ε × M × c²**

Where ε ≈ 10⁻¹⁵ is the mass-to-light conversion efficiency (nuclear burning rate integrated over cosmic time).

### 3.3 Validation

| Galaxy | L (L☉) | v_rot (km/s) | k | L × k² (W) | L × k²/(Mc²) |
|--------|--------|--------------|---|------------|--------------|
| Milky Way | 1.5 × 10¹⁰ | 220 | 1363 | 1.07 × 10⁴³ | 5.96 × 10⁻¹⁶ |
| Triangulum | 5 × 10⁹ | 130 | 2306 | 1.02 × 10⁴³ | 1.14 × 10⁻¹⁵ |
| NGC 2403 | 3 × 10⁹ | 135 | 2221 | 5.66 × 10⁴² | 1.06 × 10⁻¹⁵ |

The ratio L × k² / (Mc²) clusters around 10⁻¹⁵ for spiral galaxies.

## 4. Flat Rotation Curves Without Dark Matter

### 4.1 The Geometric Explanation

In SDT, gravitational effects arise from pressure gradients in the spation field. For a disk galaxy:

- The pressure deficit extends beyond the visible disk
- The occlusion function E(r) decreases gradually with radius
- This produces a slower-than-Keplerian decline in the pressure gradient

The result: **v(r) remains approximately constant** at large r, not because of additional unseen mass, but because the pressure geometry of a disk differs from a point source.

### 4.2 Prediction

For a disk of radius R_disk and characteristic k:

**v(r) = (c/k) × f(r/R_disk)**

Where f is a geometric function that asymptotes to a constant at large r for disk geometries.

## 5. Implications

### 5.1 Mass Determination

Galactic baryonic mass can be determined directly from observables:

**M = L × k² / (ε × c²)**

This requires only:
- Luminosity L (photometry)
- Rotation velocity v_rot (spectroscopy)
- Universal efficiency ε ≈ 10⁻¹⁵

### 5.2 No Dark Matter Required

The "missing mass" problem dissolves when:
1. The correct geometric scaling (L × k² ∝ Mc²) is used
2. Disk geometry effects on rotation curves are included
3. The Tully-Fisher relation (L ∝ v⁴) is recognized as an approximation to the deeper relation

## 6. Conclusion

The universal invariant z × k² = 1, which emerges from the geometric foundations of spatial displacement theory, extends naturally from stellar to galactic scales. The relationship L × k² = ε Mc² provides a direct method for determining galactic mass from luminosity and rotation velocity alone. Flat rotation curves emerge naturally from disk pressure geometry without requiring dark matter. This framework unifies atomic, stellar, and galactic dynamics under a single geometric principle.

## References

1. Tyndall, J. (2024). Spatial Displacement Theory: Foundational Principles.
2. Rubin, V.C., Ford, W.K. (1970). Rotation of the Andromeda Nebula. ApJ 159, 379.
3. Tully, R.B., Fisher, J.R. (1977). A new method of determining distances to galaxies. A&A 54, 661.

---

*Correspondence: [author contact]*  
*Data availability: All calculations reproducible from stated parameters.*
