# Cosmological Redshift as Thermal Pressure Gradient: An Alternative to Metric Expansion

**Author:** James Tyndall  
**Date:** December 2025  
**Keywords:** Cosmological redshift, CMB, pressure gradient, non-expanding universe, dark energy alternative

## Abstract

We propose that cosmological redshift arises not from metric expansion or Doppler recession, but from photon energy loss traversing a thermal pressure gradient. In this framework, the cosmic microwave background (CMB) represents the high-pressure origin from which all photons have been "climbing out," losing energy proportionally to the pressure differential. This interpretation yields identical mathematical predictions to standard cosmology while eliminating the need for metric expansion, inflation, and dark energy. The framework unifies gravitational redshift (z_grav = gR/c²) and cosmological redshift under a single physical mechanism: energy loss through pressure gradients. We propose a falsifiable test using differential gravitational redshift measurements of stellar types within distant galaxy clusters.

## 1. Introduction

The standard cosmological model interprets redshift as Doppler shift from recession velocity, implying universal expansion. This interpretation requires:

1. An initial singularity (Big Bang)
2. Superluminal early expansion (inflation)
3. Accelerating expansion (dark energy)

Each addition addresses observational anomalies but lacks independent physical motivation.

We present an alternative: **redshift as pressure gradient traversal**, where the CMB temperature ratio directly gives the redshift without invoking expansion.

## 2. The Standard Interpretation and Its Circularity

### 2.1 The Argument

Standard cosmology reasons:
- Distant galaxies show redshift
- Redshift implies recession velocity (Doppler)
- Recession implies expansion
- Expansion implies past singularity

### 2.2 The Problem

The Doppler interpretation is not independently verified. The reasoning is:

*"Why are they red? Because they're moving away. Why are they moving away? Because they're red."*

No independent measurement confirms that redshift equals recession velocity at cosmological scales. The interpretation is assumed, not demonstrated.

## 3. Redshift as Pressure Gradient

### 3.1 Local Gravitational Redshift

Near any massive body, photons climbing out of a gravitational well lose energy:

**z_grav = GM/(Rc²) = gR/c²**

This is experimentally verified. The photon loses energy proportional to the potential traversed.

### 3.2 Generalization to Pressure Fields

In spatial displacement theory, gravitational effects arise from pressure gradients in the spation field. The gravitational redshift formula becomes:

**z = ΔΠ/Π_∞**

Where Π is the spation pressure and Π_∞ is the reference pressure at infinity.

### 3.3 Cosmological Application

The early universe was hot. The CMB represents the thermal state at decoupling:

- **T_then** = 3000 K (recombination temperature)
- **T_now** = 2.725 K (measured CMB temperature)

For radiation, temperature determines pressure: P_rad = (1/3)aT⁴

The redshift from thermal pressure gradient:

**z = T_then/T_now - 1 = 3000/2.725 - 1 ≈ 1100**

This matches the observed CMB redshift of z = 1089 within measurement precision.

### 3.4 No Expansion Required

The photon wasn't "stretched by expanding space." It **lost energy climbing out of a hot pressure bath into cold space.**

The universe isn't expanding. It's **cooling**. We observe the thermal history, not the velocity history.

## 4. Unification of Redshift Mechanisms

### 4.1 The Same Physics at All Scales

| Scale | Redshift Mechanism | Formula |
|-------|-------------------|---------|
| Stellar | Gravitational well | z = gR/c² |
| Galactic | Cluster potential | z = GM/(Rc²) |
| Cosmological | Thermal pressure gradient | z = T_then/T_now - 1 |

All are pressure gradient effects. The photon loses energy traversing any pressure differential.

### 4.2 Observed Redshift is Additive

For a star in a distant galaxy:

**z_total = z_cosmic + z_grav**

Where:
- z_cosmic is the thermal gradient to that distance
- z_grav is the local gravitational redshift at the star's surface

## 5. Reinterpretation of Cosmological Parameters

### 5.1 The Hubble "Constant"

Standard interpretation: H₀ = v/d (recession velocity per unit distance)

Pressure interpretation: H₀ = (1/c)(dP/dr) (pressure gradient per unit distance)

The numerical value is identical. The physical meaning differs.

### 5.2 Dark Energy

Standard cosmology requires dark energy (Λ) to explain apparent acceleration at high z.

In the pressure framework, the "acceleration" is simply the non-linear shape of the thermal history:

**dT/dt was not constant → d²z/dt² ≠ 0**

The universe cooled faster initially, slower later. This mimics "acceleration" in the expansion interpretation. No dark energy required.

### 5.3 The CMB as Pressure Reference

The CMB isn't just leftover light. It's the **universal pressure floor**:

- P_∞ = pressure at CMB temperature
- All local z measurements are against this reference
- The invariant z × k² = 1 uses c² = P_∞/ρ_s as the reference pressure

## 6. Falsifiable Prediction

### 6.1 The Test

Within a single distant galaxy cluster, individual stars should show **systematic z variation by stellar type**:

- White dwarfs: z_total = z_cosmic + ~10⁻⁴ (high z_grav)
- G dwarfs: z_total = z_cosmic + ~10⁻⁶
- K giants: z_total = z_cosmic + ~10⁻⁶

The **differential** between stellar types gives pure z_grav, independent of z_cosmic.

### 6.2 Prediction

If this framework is correct:
1. The z spread within a cluster should match local z_grav measurements
2. z_cosmic should be **identical** for all stellar types in the same cluster
3. The spread should correlate with log_g (spectroscopic surface gravity)

### 6.3 Observational Requirements

- High-resolution spectroscopy (Δz ~ 10⁻⁵)
- Multiple stellar types in a single cluster at z ~ 0.1
- Independent log_g measurements from line broadening

This is achievable with current instruments (VLT, Keck echelle spectrographs).

## 7. Implications

### 7.1 No Singularity

If redshift is thermal, not velocity, the "Big Bang singularity" disappears. The universe had a **maximum pressure state**, not an infinite density point.

### 7.2 No Inflation

Early universe redshift is simply higher temperature, not superluminal expansion. Inflation becomes unnecessary.

### 7.3 No Dark Energy

The apparent acceleration is thermal history curvature, not exotic energy. Λ = 0.

### 7.4 Standard Candles Become Optional

Distance measurement via differential z_grav:

1. Measure z_total for multiple stellar types in target system
2. Subtract known z_grav by type
3. Remainder = z_cosmic (uniform across types)
4. z_cosmic gives thermal distance

No Cepheid calibration. No Type Ia assumptions. Pure geometry.

## 8. Conclusion

Cosmological redshift admits a simpler interpretation: photons lose energy traversing thermal pressure gradients, not because space expands. This framework:

1. Unifies gravitational and cosmological redshift
2. Eliminates singularities, inflation, and dark energy
3. Makes falsifiable predictions testable with current technology
4. Maintains all successful predictions of standard cosmology

The universe is not expanding. It is cooling. Redshift is a thermometer, not a speedometer.

## References

1. Tyndall, J. (2024). Spatial Displacement Theory: Foundational Principles.
2. Penzias, A.A., Wilson, R.W. (1965). A Measurement of Excess Antenna Temperature at 4080 Mc/s. ApJ 142, 419.
3. Riess, A.G. et al. (1998). Observational Evidence from Supernovae for an Accelerating Universe. AJ 116, 1009.

---

*Correspondence: [author contact]*  
*Data availability: All calculations reproducible from stated parameters.*
